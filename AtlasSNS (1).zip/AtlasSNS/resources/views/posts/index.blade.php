@extends('layouts.login')

@section('content')
<h2>機能を実装していきましょう。</h2>

@endsection